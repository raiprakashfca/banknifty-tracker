from kiteconnect import KiteConnect
import os
import toml

api_key = os.environ["ZERODHA_API_KEY"]
api_secret = os.environ["ZERODHA_API_SECRET"]
request_token = os.environ["ZERODHA_REQUEST_TOKEN"]

kite = KiteConnect(api_key=api_key)
session = kite.generate_session(request_token, api_secret=api_secret)
access_token = session["access_token"]

with open("secrets.toml", "w") as f:
    f.write(toml.dumps({
        "api_key": api_key,
        "api_secret": api_secret,
        "access_token": access_token
    }))

print("✅ Updated secrets.toml")
